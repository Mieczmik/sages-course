# Z 52 elementowej talii kart, wylosuj 20 i oblicz procent 'silnych kart'
# wśrod wszystkich. Przyjmij, ze silnych kart w talii jest 16, a słabych 36
import random

