# STWORZ FUNKCJE LOSUJĄCĄ od 1 do 6 tak długo aż nie wylosuje 6.
# Jesli jej sie uda, niech zwróci uzytkownikowi ile razy próbowała
import random
