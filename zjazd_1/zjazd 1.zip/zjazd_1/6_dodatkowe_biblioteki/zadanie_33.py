# Stwórz funkcje liczyć średnią z listy 10000 wylosowanych liczb w zakresie 1-100
import random
from statistics import mean

