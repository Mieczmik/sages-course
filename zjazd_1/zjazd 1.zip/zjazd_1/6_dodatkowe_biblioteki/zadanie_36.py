# bieda-poker: Talia kart zawiera karty w kolorach: pik, kier, karo, trefl
# w zakresie od 1 do 14. Napisz funkcje, która przyjmie liczbe graczy,
# potasuje talie kart, odrzuci tyle, aby każdy gracz mial po równo
# a nastepnie rozda karty (kazdy gracz dostaje co n-tą karte).
# Nastepnie policz, który gracz / gracze otrzymał największą liczbe kart
# tego samego koloru.
import random
import itertools
