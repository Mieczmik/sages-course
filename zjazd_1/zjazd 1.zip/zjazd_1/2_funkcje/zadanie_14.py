# Zadanie 14: Napisz kalkulator (suma, odejmowanie, mnożenie,
# dzielenie)
# dla dwóch liczb, sprawdź, czy użytkownik podaje odpowiednie
# typy danych
# i czy nie chce dzielić przez zero
# mn = mnozenie
# dz = dzielenie
# od - odejmowanie
# do - dodawania

