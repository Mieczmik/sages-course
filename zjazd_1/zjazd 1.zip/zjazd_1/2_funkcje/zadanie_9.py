# ZADANIE 9: Napisz 2_funkcje, zamieniającą pierwszą
# literę a w napisie na "X".
# Ala -> Xla

print('ala ma kota kota'.find('kota'))

moj_napis = 'LAla'
