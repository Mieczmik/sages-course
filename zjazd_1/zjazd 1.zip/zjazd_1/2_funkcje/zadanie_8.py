# ZADANIE 8: Napisz 2_funkcje, zamieniającą literę a
#  w napisie na "X". ‘Ala’ -> XlX
inputStr = "Ala"

