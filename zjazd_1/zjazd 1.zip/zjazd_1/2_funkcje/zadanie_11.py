# ZADANIE 11: napisz 2_funkcje przyjmującą string.
# Policz ile razy
# znajduje się słowo "usa", niezależnie od wielości
# liter

zdanie = 'Usa wybory w usa, USA'
wyraz = 'USA'



