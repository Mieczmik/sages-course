# ZADANIE 17: napisz funkcję, która będzie przyjmowała napis,
# a zwracała jego elementy w odwrotnej kolejności np
# "pies je kiełbase'-> 'kiełbase je pies’

moj_napis = "pies je kiełbase"
# moj_napis.split() -> lista słow
# łączenie elementow listy w string -> " ".join()
