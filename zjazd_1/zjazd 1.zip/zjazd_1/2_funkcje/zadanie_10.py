# ZADANIE 10: Stwórz funkcję przyjmującą string.
# Policz ile znajduje się w nim liter,
# znaków specjalnych oraz cyfr
input_str = "P#@yn26at^&i5ve"


