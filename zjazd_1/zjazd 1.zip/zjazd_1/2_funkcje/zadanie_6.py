# ZADANIE 6: Napisz funkcje przyjmującą dwa argumenty
# typu int.
# Jeśli ich iloczyn jest większy od 1000, zwróć ich sume.
