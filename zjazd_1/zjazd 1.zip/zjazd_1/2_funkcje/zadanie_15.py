# Zadanie 15: Stwórz funkcję liczącą ile cyfr jest
# w podanej liczbie


