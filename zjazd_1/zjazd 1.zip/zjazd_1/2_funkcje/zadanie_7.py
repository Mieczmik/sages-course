# ZADANIE 7: napisz funkcję przyjmującą string z wielkimi
#  i małymi literami,
# zwróć nowy string, który będzie zawierał najpierw małe
# potem wielkie litery napisu.
# ‘DoM jESt’ > ‘ojtDMES’
inputStr = "DoM jESt"
