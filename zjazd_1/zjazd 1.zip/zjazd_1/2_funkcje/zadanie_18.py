# ZADANIE 18: Napisz funkcję usuwającą znaki specjalne
my_str = "Napis, (ze znakami !) specjalnymi ? %$\n"


