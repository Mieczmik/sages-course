# ZADANIE 12: Stwórz funkcję przyjmującą zbiór liczb
# od 1 do 10,
# która dla każdego elementu listy będzie wyświetlała
# sume elementu
# i poprzednich elementów


