# ZADANIE DODATKOWE 19: Napisz 2_funkcje,
# ktorej zadaniem będzie dodanie dwóch macierzy:
# => [17, 15, 4]
# [10, 12, 9]
# [11, 13, 18]

X = [[12,7,3],
     [4 ,5,6],
     [7 ,8,9]]
Y = [[5,8,1],
    [6,7,3],
    [4,5,9]]

# print(X[1][1])


