# Napisz funkcję , która będzie zwracać sume i
# iloczyn wszystkich podanych argumentów

