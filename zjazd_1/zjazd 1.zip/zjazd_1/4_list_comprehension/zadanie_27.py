# Znajdź wszystkie liczby od 10 do 30,
# które zawierają cyfre 3
nowa_lista = list(range(10,31))
print(nowa_lista)



