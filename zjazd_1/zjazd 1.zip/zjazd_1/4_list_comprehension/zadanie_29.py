# Znajdź wszystkie słowa,
# które sa krótsze niz 4 w napisie:
napis = "to jest moj super napis"



