# dla podanego stringu policz ilosc wystepowania
# litery 'a'
# (bez użycia .count).
string = 'Ala ma kota i dom'#.lower()
# print(s.count('a'))

