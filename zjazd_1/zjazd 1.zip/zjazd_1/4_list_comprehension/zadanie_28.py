# Usun wszystkie samogloski z napisu
napis = "Ala ma Kota i dom" #-> "l m Kt  dm"
lista_samogłosek = 'aeiouAEIOU'

