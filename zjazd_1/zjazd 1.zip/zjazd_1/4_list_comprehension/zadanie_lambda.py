# ZADANIE : Napisz wyrazenie lambda,
# które podniesie kazdy element do potegi 2
lista = [2,3,4]
