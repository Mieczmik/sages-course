# napisz formułe, która z dwóch list wybierze
# element większy:

print(max([1,2,3]))
print(sum([1,2,3]))


