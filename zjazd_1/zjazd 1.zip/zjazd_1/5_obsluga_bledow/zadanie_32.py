# Popraw poniszy kod wykorzystując:
# ZeroDivisionError, ValueError, IndexError, TypeError.
def example1():
    x = int(input("enter a number: "))
    y = int(input("enter another number: "))
    print(x / y)


# example1()

def example2(lista):
    suma = []
    for i in range(len(lista)):
        suma.append(lista[i] + lista[i + 1])
        print(suma)
