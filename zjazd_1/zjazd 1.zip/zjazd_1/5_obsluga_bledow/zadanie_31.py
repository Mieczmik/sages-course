# Napisz funkcję dzieląca liczby,
# z uwzględnieniem ZeroDivisionError oraz TypeError.
# Jeśli uzytkownik poda ktorąś z liczb większą od
# 100 zwróc jakiś błąd (ValueError). -> raise ValueError
