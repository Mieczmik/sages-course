# ZADANIE 2: w podanym napisie wyświetl wszystkie słowa
# na literę "a":
napis = 'ala ma kota a anna psa'


