# ZADANIE 3 : Za pomocą while stworz petle odliczajaca
# od 5 do zera. Nie wyswietlaj 2.
